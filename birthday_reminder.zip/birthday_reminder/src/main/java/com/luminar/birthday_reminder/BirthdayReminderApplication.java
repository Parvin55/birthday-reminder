package com.luminar.birthday_reminder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BirthdayReminderApplication {

	public static void main(String[] args) {
		SpringApplication.run(BirthdayReminderApplication.class, args);
	}

}
